#define TRANS_TN
#include "sbgemm_small_kernel_template_cooperlake.c"
