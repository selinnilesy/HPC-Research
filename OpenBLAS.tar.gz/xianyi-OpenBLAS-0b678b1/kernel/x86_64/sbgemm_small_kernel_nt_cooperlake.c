#define TRANS_NT
#include "sbgemm_small_kernel_template_cooperlake.c"
